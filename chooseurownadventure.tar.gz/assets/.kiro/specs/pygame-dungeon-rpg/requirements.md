# Requirements Document

## Introduction

This document describes the requirements for rewriting the existing terminal-based Egyptian-mythology dungeon crawler into a proper turn-based RPG using pygame, with full web-deployment compatibility via pygbag. The game preserves its existing narrative (Khonshu, Horus, the dungeon heart, three distinct endings), its core mechanics (sanity system, d20/d6 dice rolling, saving roll, negotiation, enemy modifiers), and its Egyptian-mythology aesthetic, while adding a graphical front-end, party management, animated combat, equippable gear, a persistent HUD, room-by-room dungeon traversal, scaling difficulty, additional bosses, freeplay mode, and more complex enemy attack patterns.

All blocking I/O and `time.sleep` calls from the original codebase are replaced with non-blocking async equivalents so the game loop is compatible with pygbag's `asyncio`-based web runtime.

---

## Glossary

- **Game**: The pygame-based dungeon RPG application being specified.
- **Engine**: The pygame rendering and event loop at the core of the Game.
- **AsyncLoop**: The top-level `asyncio` coroutine that drives the Engine under pygbag.
- **Scene**: A discrete game state managed by the SceneManager (e.g., TitleScene, DungeonScene, CombatScene).
- **SceneManager**: The component that owns the active Scene and handles transitions between Scenes.
- **DungeonScene**: The Scene responsible for room-by-room floor traversal.
- **CombatScene**: The Scene responsible for rendering and resolving turn-based combat.
- **HUD**: The always-visible panel that displays the current party's stats during DungeonScene and CombatScene.
- **Party**: The collection of up to four PartyMembers controlled by the player.
- **PartyMember**: A single playable character with its own HP, sanity, attack, defense, agility, equipment slots, and status effects.
- **ActiveMember**: The PartyMember whose turn it is in combat.
- **Enemy**: An opponent encountered in combat, with a type (Heretic or Creature), a modifier, HP, and an attack list.
- **Boss**: A named Enemy with a fixed attack list, higher HP, and scripted dialogue; not randomly generated.
- **Modifier**: A special property attached to an Enemy: Shielded, True Damage, Thief, or Fanatic.
- **Attack**: A named action with a base damage value and an optional special effect.
- **SpecialEffect**: One of: `critical`, `selfdamage`, `suicide`, `chargeup`, `truedamage_pierce`.
- **ChargeAttack**: An Attack with `chargeup` SpecialEffect; it telegraphs on turn N and deals double damage on turn N+1.
- **D20Roll**: A weighted random integer in [1, 20] used as a damage multiplier during the player's attack turn.
- **D6Roll**: A random integer in [1, 6] used for critical-hit guessing, saving rolls, and negotiation checks.
- **SavingRoll**: The mechanic that lets a player gamble sanity on a D6Roll to revive after death.
- **Sanity**: A per-PartyMember stat in [0, 200] that determines PlayerClass and affects negotiation outcomes.
- **PlayerClass**: The role label derived from a PartyMember's sanity (Fiend ≤50, Branded 51–74, Human 75–174, Enlightened 175–199, Fanatical 200).
- **EquipSlot**: One of three gear slots on a PartyMember: Weapon, Armor, Accessory.
- **EquippableItem**: An item that occupies one EquipSlot and passively modifies stats while equipped.
- **ConsumableItem**: A single-use item that applies a temporary or permanent stat change.
- **Inventory**: The shared list of items held by the party.
- **Floor**: One of the seven dungeon levels; each Floor contains one or more Rooms.
- **Room**: A discrete dungeon space that may contain an enemy encounter, an item, lore text, or a rest point.
- **DungeonHeart**: The narrative objective on Floor 7; destroying it triggers the Khonshu or Dream ending depending on player choices.
- **FreeplayMode**: An endless combat sandbox unlocked after completing one full run; difficulty scales indefinitely.
- **TypewriterRenderer**: The component that renders dialogue text character-by-character in pygame at a configurable speed.
- **CombatAnimator**: The component that plays attack flash, hit shake, and enemy damage animations in CombatScene.
- **PlaceholderSurface**: A filled rectangle with a comment describing the intended texture; used where art assets are not yet available.
- **Khonshu**: The narrator god and primary antagonist; a Boss on floor 7 (triggered by the Scarab Amulet) and the subject of the good ending.
- **Horus**: The opposing god encountered on floor 7 as a Boss; killing him leads to the dream ending or the Khonshu battle.
- **ScarabAmulet**: A key item that, when used during the Horus battle, triggers the Khonshu boss fight and reveals the dungeon's true nature.

---

## Requirements

### Requirement 1: pygbag-Compatible Async Game Loop

**User Story:** As a player, I want to play the game in a web browser via pygbag, so that I can enjoy it without installing Python.

#### Acceptance Criteria

1. THE AsyncLoop SHALL be implemented as a top-level `async def main()` coroutine and called via `asyncio.run(main())`.
2. WHEN the Engine processes one frame, THE AsyncLoop SHALL call `await asyncio.sleep(0)` to yield control back to the browser event loop.
3. THE Game SHALL NOT call `time.sleep()`, `input()`, or any other blocking call outside of an async wrapper.
4. THE Engine SHALL load all assets using `pathlib.Path` or relative paths compatible with pygbag's virtual filesystem.
5. WHERE the Game runs in a web context, THE Engine SHALL fall back to a fixed 60 FPS cap using `pygame.time.Clock`.

---

### Requirement 2: Scene Management

**User Story:** As a developer, I want a clean scene graph, so that each game state (title, dungeon, combat, endings) is isolated and testable.

#### Acceptance Criteria

1. THE SceneManager SHALL maintain exactly one active Scene at any given time.
2. WHEN a Scene requests a transition, THE SceneManager SHALL deactivate the current Scene and activate the requested Scene within the same frame.
3. THE SceneManager SHALL pass a shared game-state context object to each Scene on activation.
4. IF a Scene transition targets a Scene that does not exist, THEN THE SceneManager SHALL log the error and remain on the current Scene.
5. THE Game SHALL implement the following Scenes at minimum: TitleScene, DungeonScene, CombatScene, InventoryScene, PartyScene, EndingScene, FreeplayScene.

---

### Requirement 3: Typewriter Text Renderer

**User Story:** As a player, I want dialogue and narrative text to appear character by character, so that the game retains the atmospheric pacing of the original.

#### Acceptance Criteria

1. THE TypewriterRenderer SHALL accept a string, a target pygame Surface, a font, a color, a bounding Rect, and a characters-per-second rate.
2. WHEN the TypewriterRenderer is advancing, THE TypewriterRenderer SHALL render one additional character per elapsed tick, calculated from the characters-per-second rate and delta time.
3. WHEN the player presses the confirm key (Space or Enter) while the TypewriterRenderer is advancing, THE TypewriterRenderer SHALL immediately render the full string.
4. WHEN the TypewriterRenderer has rendered all characters, THE TypewriterRenderer SHALL emit a `text_complete` event.
5. THE TypewriterRenderer SHALL support text wrapping within the provided bounding Rect.
6. THE TypewriterRenderer SHALL NOT block the game loop while advancing.

---

### Requirement 4: Combat Animations

**User Story:** As a player, I want visual feedback during attacks and hits, so that combat feels impactful.

#### Acceptance Criteria

1. WHEN a PartyMember executes an attack, THE CombatAnimator SHALL display an attack-flash effect on the attacker's sprite for 150–300 ms.
2. WHEN an Enemy or PartyMember receives damage, THE CombatAnimator SHALL apply a screen-shake effect with a magnitude proportional to the damage dealt, lasting 200–400 ms.
3. WHEN an Enemy or PartyMember receives damage, THE CombatAnimator SHALL flash the target's sprite to a damage color (red tint) for 100–200 ms.
4. WHEN a critical hit is scored, THE CombatAnimator SHALL play an enlarged flash effect with 1.5× the standard shake magnitude.
5. WHILE an animation is playing, THE CombatScene SHALL NOT advance to the next combat phase.
6. THE CombatAnimator SHALL expose a `is_playing` boolean property that returns True while any animation is active.

---

### Requirement 5: Party System

**User Story:** As a player, I want to build a party of multiple characters, so that I have strategic options in combat.

#### Acceptance Criteria

1. THE Party SHALL hold between one and four PartyMembers.
2. WHEN the game is started, THE Game SHALL allow the player to name the first PartyMember before entering the dungeon.
3. WHEN a PartyMember's HP reaches 0, THE CombatScene SHALL prompt the SavingRoll for that PartyMember before marking them as defeated.
4. WHILE at least one PartyMember has HP greater than 0, THE CombatScene SHALL continue the current combat encounter.
5. WHEN all PartyMembers have HP equal to 0, THE CombatScene SHALL trigger the game-over flow.
6. THE HUD SHALL display the name, HP, sanity, and PlayerClass of every PartyMember simultaneously.
7. WHEN a new PartyMember joins the party (found in a Room), THE Party SHALL add them to the party roster and THE HUD SHALL update to reflect the new roster.
8. WHEN the player selects an action in CombatScene, THE ActiveMember SHALL be the PartyMember whose turn it currently is, advancing in party-roster order each turn.

---

### Requirement 6: Equippable Item System

**User Story:** As a player, I want to equip weapons, armor, and accessories on my party members, so that I can customize their stats permanently.

#### Acceptance Criteria

1. EACH PartyMember SHALL have exactly three EquipSlots: Weapon, Armor, and Accessory.
2. WHEN an EquippableItem is equipped to a PartyMember, THE PartyMember's relevant stat(s) SHALL increase by the item's stat modifier immediately.
3. WHEN an EquippableItem is unequipped from a PartyMember, THE PartyMember's relevant stat(s) SHALL decrease by the item's stat modifier immediately.
4. WHEN a PartyMember equips an EquippableItem to a slot that is already occupied, THE InventoryScene SHALL unequip the existing item to the Inventory before equipping the new item.
5. THE InventoryScene SHALL display all items in the Inventory grouped by type (EquippableItem, ConsumableItem, key items) and show each PartyMember's current equipment.
6. THE Weapon EquipSlot SHALL modify the `attack` stat; the Armor EquipSlot SHALL modify the `defense` stat; the Accessory EquipSlot SHALL modify one of `agility`, `sanity`, or `playerhealth`.

---

### Requirement 7: Persistent HUD

**User Story:** As a player, I want to always see my party's stats on screen, so that I can make informed decisions during exploration and combat.

#### Acceptance Criteria

1. THE HUD SHALL be rendered on every frame during DungeonScene and CombatScene.
2. THE HUD SHALL display, for each PartyMember: name, HP (current/max), sanity, PlayerClass, and any active temporary stat buffs indicated with an up-arrow and value.
3. WHEN a PartyMember's sanity changes, THE HUD SHALL update the displayed PlayerClass label within the same frame.
4. THE HUD SHALL occupy a fixed region of the screen that does not overlap the main game viewport.
5. THE HUD SHALL use a PlaceholderSurface as its background panel, described as: "Stone tablet texture with hieroglyph border."

---

### Requirement 8: Room-by-Room Dungeon Traversal

**User Story:** As a player, I want to navigate through rooms within each floor, so that exploration feels purposeful and varied.

#### Acceptance Criteria

1. EACH Floor SHALL contain between 3 and 6 Rooms generated at dungeon-start, including exactly one exit Room.
2. WHEN the player enters a Room, THE DungeonScene SHALL randomly determine the Room's content from: combat encounter (60%), item cache (20%), rest point (10%), lore fragment (10%).
3. WHEN a Room contains a combat encounter, THE DungeonScene SHALL transition to CombatScene; WHEN that combat ends, THE DungeonScene SHALL return the player to the same Room marked as cleared.
4. WHEN a Room contains a rest point, THE DungeonScene SHALL restore each PartyMember's HP by 25% of their maximum HP.
5. WHEN the player enters the exit Room, THE DungeonScene SHALL advance to the next Floor.
6. THE DungeonScene SHALL render a map of the current Floor's Rooms as connected nodes, highlighting the current Room and cleared Rooms.
7. THE DungeonScene SHALL use PlaceholderSurfaces for all Room backgrounds, each described per room type (e.g., "Dark stone corridor with torch sconces", "Treasure alcove with golden artifacts", "Underground shrine with Ankh carvings").

---

### Requirement 9: Core Combat System (Preserved Mechanics)

**User Story:** As a player, I want the original combat mechanics to work in the pygame version, so that the strategic depth of the original game is preserved.

#### Acceptance Criteria

1. THE CombatScene SHALL support four player actions per turn: Attack, Block, Item, and Negotiate (Negotiate only when enemy Modifier is Fanatic).
2. WHEN the player chooses Attack, THE CombatScene SHALL display a D20Roll animation and calculate damage as: `round((attack_base * d20_roll) / 1.5, 1) + party_member_attack_stat`.
3. WHEN the player chooses Block, THE CombatScene SHALL halve all incoming damage for that turn and set a blocking flag that resets at the start of the next enemy turn.
4. THE D20Roll SHALL use a weighted distribution where weights for results 1–12 are 1.0, results 13–17 are `0.2 * attack_stat`, and results 18–20 are `0.3 * (temp_attack + 1)`.
5. WHEN an Attack has the `critical` SpecialEffect, THE CombatScene SHALL prompt the player to guess a D6 value; IF `abs(guess - roll) <= 1`, THEN the damage SHALL be tripled.
6. WHEN a PartyMember's HP reaches 0, THE CombatScene SHALL trigger the SavingRoll mechanic for that PartyMember.
7. WHEN the SavingRoll is triggered, THE CombatScene SHALL deduct sanity points wagered by the player and resolve a D6Roll; IF the roll matches one of the player's chosen numbers, THEN the PartyMember's HP SHALL be restored to 150.
8. WHEN an Enemy has the Shielded Modifier, THE CombatScene SHALL route all player damage to the Enemy's shield_hp until shield_hp reaches 0, then to enemy_hp.
9. WHEN an Enemy has the True Damage Modifier, THE CombatScene SHALL reduce the effectiveness of the PartyMember's defense stat by `5 * difficulty` percent when calculating incoming damage.
10. WHEN an Enemy has the Thief Modifier and the combat ends in Victory, THE CombatScene SHALL award the party two additional items from the permanent item pool.
11. WHEN an Attack has the `selfdamage` SpecialEffect, THE CombatScene SHALL subtract `round(attack_damage / 0.7)` HP from the Enemy in addition to inflicting normal damage.
12. WHEN an Attack has the `suicide` SpecialEffect, THE CombatScene SHALL reduce the Enemy's HP to 10% of its current value.
13. WHEN the player successfully negotiates with a Fanatic enemy, THE CombatScene SHALL end the encounter as a negotiation victory and award sanity equal to `10 * difficulty`.

---

### Requirement 10: Charge-Up Enemy Attacks

**User Story:** As a player, I want some enemies to telegraph powerful attacks in advance, so that I can plan my defensive moves.

#### Acceptance Criteria

1. WHEN an Enemy selects an Attack with the `chargeup` SpecialEffect on its turn, THE CombatScene SHALL display a visible charge indicator on the enemy's combat panel for one full turn.
2. WHEN a charge indicator is active and the Enemy's next turn arrives, THE CombatScene SHALL execute the charged Attack with double its base damage value.
3. WHEN a charged Attack is telegraphed, THE HUD SHALL display a warning message identifying the upcoming attack by name.
4. IF a charged Enemy is defeated before its charge resolves, THEN THE CombatScene SHALL clear the charge indicator without dealing damage.
5. EACH enemy type at difficulty ≥ 3 SHALL have at least one Attack with the `chargeup` SpecialEffect in its attack pool.

---

### Requirement 11: Sanity and Player Class System (Preserved)

**User Story:** As a player, I want my sanity to affect my class and available options, so that resource management has meaningful consequences.

#### Acceptance Criteria

1. WHEN a PartyMember's sanity changes, THE Game SHALL recalculate that member's PlayerClass: sanity ≤ 50 → Fiend, 51–74 → Branded, 75–174 → Human, 175–199 → Enlightened, 200 → Fanatical.
2. WHEN a PartyMember's PlayerClass is Fanatical, THE CombatScene SHALL make the Negotiate action available for all enemy types (not only Fanatic-modifier enemies).
3. WHEN a PartyMember's PlayerClass is Fiend, THE CombatScene SHALL apply a +2 bonus to that member's base attack stat for the duration of combat.
4. WHEN a successful negotiation occurs with a Corrupt personality enemy, THE CombatScene SHALL deduct `difficulty * 7` sanity from the ActiveMember.
5. WHEN a PartyMember's sanity reaches 0, THE CombatScene SHALL treat that member as having entered a berserk state where they attack enemies and allies randomly.

---

### Requirement 12: Enemy Diversity and Scaling Difficulty

**User Story:** As a player, I want enemies to grow more dangerous as I progress, so that later floors remain challenging.

#### Acceptance Criteria

1. THE CombatScene SHALL scale enemy HP using the formula: `random.randint(55, 85) * (1 + 0.5 * difficulty)`.
2. WHEN the player advances to Floor N, THE DungeonScene SHALL set the base difficulty to `1 + ((N - 1) // 2)`.
3. EVERY third Floor, THE DungeonScene SHALL award the party one new Attack with a player-chosen name.
4. THE enemy pool SHALL include at minimum: the original Heretic attack list (Stab, Slash, Dagger Throw, Blood Spit, Sacrifice) and Creature attack list (Shudder, Bite, Scream, Claw, Shatter), plus two new enemy types introduced in this rewrite: Revenant and Architect.
5. THE Revenant enemy type SHALL have an attack pool containing at least one `chargeup` Attack and one `selfdamage` Attack.
6. THE Architect enemy type SHALL have an attack pool that includes an attack which raises the enemy's own shield_hp mid-combat.

---

### Requirement 13: Boss Fights

**User Story:** As a player, I want memorable boss encounters with unique mechanics, so that floor completion feels rewarding.

#### Acceptance Criteria

1. THE Game SHALL include the following Bosses: Horus (Floor 7 entry), Khonshu (triggered by ScarabAmulet during Horus fight), Anubis (Floor 4), and Set (Floor 6).
2. WHEN the Horus Boss fight begins, THE CombatScene SHALL set Horus's attack pool to: Gale Wing (3), Talon Sweep (4), Solar Flare (5), Vengeance (6, `selfdamage`), Judgement (7, `selfdamage`).
3. WHEN the player uses the ScarabAmulet during the Horus fight, THE CombatScene SHALL display the scripted Scarab dialogue, end the Horus fight, and immediately transition to the Khonshu Boss fight.
4. WHEN the Khonshu Boss fight ends with Khonshu at 0 HP, THE Game SHALL transition to the Good Ending scene.
5. WHEN the Horus Boss fight ends with the player choosing to follow Horus, THE Game SHALL transition to the Dream Ending scene.
6. WHEN the Horus Boss fight ends with the player refusing Horus and Khonshu initiating combat, THE Game SHALL transition to the Khonshu Ending scene upon player defeat.
7. THE Anubis Boss SHALL have a `chargeup` attack (Scales of Ma'at: charges for 1 turn, deals `8 * difficulty` damage) and a mechanic that checks the player's sanity: IF ActiveMember sanity < 75, THEN THE Anubis Boss SHALL deal 1.5× damage on all attacks for the remainder of that fight.
8. THE Set Boss SHALL have a Shielded Modifier with a shield_hp equal to `80 * difficulty` and an attack (Desert Storm: `chargeup`, 10 base damage) that hits all PartyMembers simultaneously.
9. EACH Boss SHALL be preceded by scripted dialogue rendered via the TypewriterRenderer before combat begins.

---

### Requirement 14: Freeplay Mode

**User Story:** As a player, I want an endless combat sandbox after completing a run, so that I can continue testing builds and experimenting.

#### Acceptance Criteria

1. WHEN the player completes a full dungeon run (any ending), THE FreeplayScene SHALL become accessible from the TitleScene.
2. THE FreeplayScene SHALL generate an infinite sequence of combat encounters with difficulty increasing by 0.5 every 5 victories.
3. THE FreeplayScene SHALL allow the player to select any unlocked enemy type (including Boss types) as the opponent before each encounter.
4. WHEN the player is defeated in FreeplayScene, THE FreeplayScene SHALL offer a restart-from-current-difficulty option without resetting the enemy unlock list.
5. THE FreeplayScene SHALL display the player's current win streak and highest difficulty reached in the HUD.

---

### Requirement 15: Inventory and Item System

**User Story:** As a player, I want to manage items and equipment between and during encounters, so that preparation matters.

#### Acceptance Criteria

1. THE Inventory SHALL hold ConsumableItems and EquippableItems without a hard cap on total count.
2. WHEN a ConsumableItem is used in combat, THE CombatScene SHALL apply its effect immediately and remove the item from the Inventory.
3. WHEN a ConsumableItem targets a stat with a `temp` prefix, THE CombatScene SHALL track the buff in a per-member temp-stat dictionary and remove the buff at the end of combat.
4. THE Game SHALL include the following predefined ConsumableItems: Ankh of [Stat] (temporary stat buff, rarity-weighted), and the following EquippableItems: Brass Knuckles (+4 attack, Weapon slot), plus additional EquippableItems found as floor rewards.
5. WHEN an item is found as a floor reward after Victory, THE DungeonScene SHALL call the item-generation function with the current difficulty as a rarity parameter.
6. THE ScarabAmulet SHALL be a key item that is neither a ConsumableItem nor an EquippableItem; it SHALL NOT be discardable and SHALL only trigger its effect during the Horus Boss fight.

---

### Requirement 16: Graphical Rendering and Placeholder Assets

**User Story:** As a developer, I want placeholder surfaces for all art assets, so that the game is structurally complete while awaiting final artwork.

#### Acceptance Criteria

1. THE Game SHALL render all backgrounds as PlaceholderSurfaces: filled rectangles with a distinct color per scene type and an inline comment describing the intended texture.
2. THE Game SHALL render all character and enemy sprites as PlaceholderSurfaces: filled rectangles of appropriate size with name labels rendered in a contrasting font.
3. WHEN a PlaceholderSurface is used, THE source code SHALL include a comment immediately preceding the surface creation in the format: `# PLACEHOLDER: [description of intended artwork]`.
4. THE Game SHALL NOT import or reference any external image files that are not present in the repository.
5. THE DungeonScene room map SHALL render as a graph of colored circles connected by lines, with Room type indicated by circle color.

---

### Requirement 17: Narrative Preservation

**User Story:** As a player, I want the original story, lore, and Egyptian mythology to be faithfully represented, so that the game's identity is preserved in the rewrite.

#### Acceptance Criteria

1. THE Game SHALL preserve the three narrative endings: Good Ending (defeat Khonshu), Dream Ending (follow Horus into the dream), and Khonshu Ending (Khonshu wins after player betrayal).
2. THE Game SHALL preserve the original Khonshu narrator dialogue style (calm, god-like, second-person address) in all TypewriterRenderer text blocks.
3. THE Game SHALL preserve the Horus opposition narrative: Horus as a truthful but dangerous entity opposing Khonshu's control.
4. THE Game SHALL preserve the ScarabAmulet reveal: the dungeon is a prison for Khonshu, not a source of nightmares to be destroyed.
5. THE Game SHALL include lore fragment Rooms on each floor that expand the Egyptian-mythology world-building (e.g., references to Ma'at, Thoth's grimoire, the Book of the Dead).
6. THE Game SHALL render the original title ASCII art on the TitleScene using a monospace font in a color matching the original gold/white palette.

---

### Requirement 18: Property-Based Testing — Combat Math

**User Story:** As a developer, I want property-based tests for all combat math functions, so that damage calculations remain correct across all stat combinations.

#### Acceptance Criteria

1. FOR ALL valid `attack_base` values in [1, 20] and `d20_roll` values in [1, 20], THE damage formula `round((attack_base * d20_roll) / 1.5, 1) + attack_stat` SHALL produce a non-negative result when `attack_stat` ≥ 0.
2. FOR ALL valid `attack_stat` and `temp_attack` values, THE D20Roll weight distribution SHALL sum to a positive total weight (no zero-weight distributions that cause `random.choices` to error).
3. FOR ALL valid `blocked_dmg` values in [0, 100] and `true_dmgpercent` values in [0, 100], THE true-damage formula SHALL produce a result in [0, base_damage] (damage cannot be amplified by defense calculation).
4. FOR ALL valid `difficulty` values in [1, 10], enemy HP generated by `random.randint(55, 85) * (1 + 0.5 * difficulty)` SHALL be strictly greater than 0.
5. FOR ALL valid `sanity` values in [0, 200], the PlayerClass lookup SHALL return exactly one of the five class labels with no gaps or overlaps in the sanity range.
6. WHEN a ChargeAttack resolves, THE final damage SHALL equal exactly double the attack's base damage value (idempotence: applying the charge multiplier once equals applying it twice produces the same doubled value when the charge flag is cleared after resolution).
7. FOR ALL valid item stat modifiers, equipping then unequipping an EquippableItem SHALL return the PartyMember's stat to its original value (round-trip property).
8. THE SavingRoll sanity deduction SHALL equal `floor(wagered_sanity / 10) * 10` plus the excess kept by Khonshu (i.e., `wagered_sanity % 10` is non-refundable), for all wagered_sanity values ≥ 0.

---

### Requirement 19: Stat Display Panel (HUD Details)

**User Story:** As a player, I want detailed stat information always visible, so that I can track buffs, debuffs, and party state at a glance.

#### Acceptance Criteria

1. THE HUD SHALL be updated every frame and SHALL reflect the current values of all PartyMember stats without requiring a scene transition.
2. WHEN a temp stat buff is active, THE HUD SHALL display the buff value with an upward-arrow prefix (e.g., "↑3") in a distinct color (blue per original palette).
3. WHEN a temp stat buff expires at end of combat, THE HUD SHALL remove the buff indicator within the first frame of the post-combat scene.
4. THE HUD SHALL visually distinguish defeated PartyMembers (e.g., greyed-out name and stats) from active members.
5. THE HUD SHALL display the current floor number and room number during DungeonScene.
