# Tasks

## Task 1: Project scaffolding and module structure
**Description:** Set up the new directory layout. Create all empty `__init__.py` files and stub modules.
**Sub-tasks:**
- [x] Create `scenes/`, `entities/`, `ui/`, `data/` directories with `__init__.py`
- [x] Create stub files: `engine.py`, `scenes/title.py`, `scenes/dungeon.py`, `scenes/combat.py`, `scenes/inventory.py`, `scenes/party.py`, `scenes/ending.py`, `scenes/freeplay.py`
- [x] Create stub files: `entities/party_member.py`, `entities/enemy.py`, `entities/attack.py`, `entities/item.py`
- [x] Create stub files: `ui/hud.py`, `ui/typewriter.py`, `ui/animator.py`
- [x] Create stub files: `data/attacks.py`, `data/enemies.py`, `data/items.py`, `data/dialogue.py`
**Dependencies:** []

## Task 2: Core data definitions
**Description:** Implement all data-layer files. No pygame required.
**Sub-tasks:**
- [x] Implement `entities/attack.py`: `Attack` dataclass with name, damage, special; assert special in VALID_SPECIALS
- [x] Implement `entities/item.py`: `Item` base, `ConsumableItem`, `EquippableItem`, `KeyItem` dataclasses
- [x] Implement `data/attacks.py`: define all attack instances (Heretic, Creature, Revenant, Architect, boss, player starting attacks)
- [x] Implement `data/items.py`: define `SCARAB_AMULET`, `BRASS_KNUCKLES`, `PERM_ITEMS` list, `generate_consumable(rarity)` function
- [x] Implement `data/dialogue.py`: all narrative text constants (KHONSHU_INTRO, SCARAB_DIALOGUE, GOOD_ENDING, DREAM_ENDING, KHONSHU_ENDING, ANUBIS_INTRO, SET_INTRO, HORUS_INTRO, KHONSHU_BOSS_INTRO, LORE_FRAGMENTS, SAVING_ROLL_PROMPT, SAVING_ROLL_CHANGE, SAVING_ROLL_SUCCESS, SAVING_ROLL_FAILURE)
**Dependencies:** [1]

## Task 3: PartyMember entity
**Description:** Implement the PartyMember dataclass with all fields, class computation, equipment management, and temp buff tracking.
**Sub-tasks:**
- [x] Implement `entities/party_member.py` with all fields per design doc
- [x] Implement `compute_class()` using sanity thresholds (Fiend≤50, Branded 51-74, Human 75-174, Enlightened 175-199, Fanatical 200)
- [x] Implement `equip(item)` and `unequip(slot)` with stat delta application; displaced item returned
- [x] Implement `_apply_equip_delta(item, sign)` for all 5 stat types
- [x] Implement `apply_temp_buff(stat, val)` and `clear_temp_buffs()`
**Dependencies:** [2]

## Task 4: Enemy entity
**Description:** Implement the Enemy dataclass and all enemy/boss factory functions in the data layer.
**Sub-tasks:**
- [x] Implement `entities/enemy.py` with all fields per design doc
- [x] Implement `choose_attack()`: if `charge_pending` set, return it; else pick random from pool; if chargeup chosen, store in `charge_pending` and return zero-damage charging placeholder
- [x] Implement `data/enemies.py`: `ATTACK_POOLS` dict, `ENEMY_NAMES`, `MODIFIERS`, `make_enemy(difficulty)` factory, `make_anubis/set/horus/khonshu(difficulty)` boss factories
**Dependencies:** [2]

## Task 5: GameState and SceneManager (engine.py)
**Description:** Implement the shared game state object and the scene manager that routes events, updates, and draws to the active scene.
**Sub-tasks:**
- [x] Implement `GameState` dataclass with all fields: party, inventory, floor, room, wins, freeplay_unlocked, freeplay_difficulty, freeplay_streak
- [x] Implement `Scene` base class interface: `on_enter`, `on_exit`, `handle_event`, `update`, `draw`
- [x] Implement `SceneManager`: scene registry dict, `register(name, scene)`, `register_all()`, `switch_to(name, context)` with error logging, `handle_event/update/draw` delegation
**Dependencies:** [1]

## Task 6: Async entry point (main.py)
**Description:** Rewrite `main.py` as a pygbag-compatible async coroutine that initializes pygame and runs the main game loop.
**Sub-tasks:**
- [x] Rewrite `main.py` as `async def main()` coroutine
- [x] Initialize pygame, create 1024×768 display, create Clock
- [x] Instantiate SceneManager, call `register_all()`, switch to "title"
- [x] Implement main loop: `clock.tick(60)`, event handling, `update(dt)`, `draw`, `display.flip()`, `await asyncio.sleep(0)`
- [x] End with `asyncio.run(main())`
- [x] Verify no `time.sleep()` or `input()` calls remain in the file
**Dependencies:** [5]

## Task 7: TypewriterRenderer (ui/typewriter.py)
**Description:** Implement the non-blocking character-by-character text renderer used for all dialogue and narrative text.
**Sub-tasks:**
- [x] Implement `TypewriterRenderer.__init__` accepting text, font, color, rect, chars_per_second
- [x] Implement `update(dt)`: advance `chars_shown` using elapsed time; set `complete = True` when done
- [x] Implement `draw(surface)`: render word-wrapped visible substring within rect
- [x] Implement `_render_wrapped`: split on spaces, accumulate lines respecting rect.width, render each line with `font.get_linesize()` spacing
- [x] Implement `skip()`: set chars_shown = len(text), complete = True
- [x] Implement `reset(new_text)`: reset all state for a new string
**Dependencies:** [5]

## Task 8: CombatAnimator (ui/animator.py)
**Description:** Implement the animation system for attack flashes, hit shakes, and damage feedback during combat.
**Sub-tasks:**
- [ ] Implement `Animation` dataclass with kind, duration, elapsed, rect, magnitude, color, alpha
- [ ] Implement `CombatAnimator` with `_animations` list and `_shake_offset`
- [ ] Implement `trigger_attack_flash(sprite_rect)`: 200ms bright overlay
- [ ] Implement `trigger_hit_shake(damage)`: 300ms shake, magnitude = min(damage/10, 20)px
- [ ] Implement `trigger_hit_flash(sprite_rect)`: 150ms red-tint at 50% opacity
- [ ] Implement `trigger_critical_flash(sprite_rect)`: 225ms gold, 1.5× inflated rect
- [ ] Implement `update(dt)`: step all animations, compute shake offset using sin decay
- [ ] Implement `draw(surface)`: blit SRCALPHA overlays for each active animation
- [ ] Implement `is_playing` property and `get_shake_offset()`
**Dependencies:** [5]

## Task 9: HUD (ui/hud.py)
**Description:** Implement the persistent heads-up display panel showing party stats, floor/room info, and temp buff indicators.
**Sub-tasks:**
- [ ] Implement `HUD.__init__(font, small_font)`
- [ ] Implement `draw(surface, game_state)`: render PLACEHOLDER stone tablet panel at x=784
- [ ] Render floor/room header at top of panel
- [ ] Implement `_draw_member(surface, member, slot_index)`: name, class label, HP bar, sanity bar, temp buff indicators
- [ ] Use grey color for defeated members
- [ ] HP bar color: green if hp_ratio > 0.4, red otherwise
- [ ] Show temp buff strings as "ATK ↑N DEF ↑N AGI ↑N" in blue when value > 0
**Dependencies:** [3, 5]

## Task 10: TitleScene (scenes/title.py)
**Description:** Implement the title screen with ASCII art rendering, blinking prompt, freeplay unlock check, and player name entry.
**Sub-tasks:**
- [x] Implement `TitleScene.on_enter(context)`: initialize scene state
- [x] Render `graphic.title` ASCII art line-by-line in gold (212, 175, 55) using monospace font
- [x] Render blinking "Press ENTER to start" (toggle at 1 Hz using elapsed time)
- [x] Render "Freeplay [F]" only if context is not None and `context.freeplay_unlocked`
- [x] Implement inline text-entry for player name: render input field, handle KEYDOWN (printable chars + BACKSPACE), confirm on ENTER (1-20 chars)
- [x] On confirm: create GameState, create first PartyMember with entered name (hp=200, max_hp=200, sanity=100, attack=5, defense=5, agility=5, starting attacks=[Punch, Tackle]), add Scarab Amulet + Brass Knuckles to inventory, switch to "dungeon"
- [x] On F key (if freeplay unlocked): switch to "freeplay"
**Dependencies:** [6, 3, 2]

## Task 11: DungeonScene (scenes/dungeon.py)
**Description:** Implement floor generation, room-type logic, map rendering, room entry handling, and boss transition triggers.
**Sub-tasks:**
- [x] Implement `Room` dataclass: room_type, cleared, pos (x,y for map rendering)
- [x] Implement floor generation in `on_enter`: generate 3-6 rooms, assign one as "exit", assign rest by weighted random (combat 60%, item 20%, rest 10%, lore 10%), assign map positions in a horizontal chain with slight y-jitter
- [x] Implement map rendering: draw edges as grey lines, then circles (radius 20) per ROOM_COLORS dict, current room highlighted with white ring
- [x] Implement PLACEHOLDER viewport background (dark stone floor color)
- [x] Implement room entry logic: combat → switch to "combat" with CombatContext, item → generate_consumable + add to inventory + typewriter confirm, rest → heal 25% max_hp capped, lore → show LORE_FRAGMENTS via typewriter, exit → advance floor or trigger boss
- [x] Implement difficulty formula: `1 + ((floor - 1) // 2)`
- [x] Handle floor 4 (Anubis boss), floor 6 (Set boss), floor 7 (Horus boss)
- [x] Every 3rd floor: prompt player to name a new attack (inline text entry), call attackmake equivalent
- [x] On return from CombatScene: mark room cleared, resume map view
**Dependencies:** [6, 4, 7, 9]

## Task 12: CombatScene state machine (scenes/combat.py)
**Description:** Implement the full turn-based combat state machine with all phases, damage formulas, animations, and special mechanics.
**Sub-tasks:**
- [x] Implement `CombatPhase` enum with all phases
- [x] Implement `on_enter(context)`: store enemy, game_state, active_member_index, reset flags (blocking, negstat, charge)
- [x] Implement PLACEHOLDER combat background (underground arena color)
- [x] Implement PLACEHOLDER party member sprites (60×80 rects with name labels) on left side
- [x] Implement PLACEHOLDER enemy sprite (80×100 rect with name/type label) on right side
- [x] Implement PLAYER_CHOOSE_ACTION phase: render action buttons [A]ttack/[B]lock/[I]tem/[N]egotiate, handle KEYDOWN
- [x] Implement PLAYER_CHOOSE_ATTACK phase: render attack list, handle number key selection
- [x] Implement ROLL_D20 phase: cycle through asciiart frames at increasing intervals (state-machine timer, not sleep), resolve damagemult using weighted random
- [x] Implement ANIMATE_ATTACK phase: call animator.trigger_attack_flash; if critical, prompt D6 guess → roll → trigger_critical_flash if hit; advance when animator.is_playing == False
- [x] Implement damage calculation: `round((attack.damage * d20_roll)/1.5, 1) + member.attack`; apply to enemy (shield routing for Shielded modifier)
- [x] Implement ENEMY_TURN phase: call enemy.choose_attack(); handle chargeup (show warning, 0 damage, set charge_pending); else compute enemy damage (standard or true damage formula), apply blocking halving, apply selfdamage/suicide specials, apply damage to active member
- [x] Implement ANIMATE_HIT phase: trigger_hit_shake + trigger_hit_flash; advance when not is_playing
- [x] Implement CHECK_WIN_LOSS phase: check enemy hp ≤ 0 (victory), check member hp ≤ 0 (saving roll), advance active member index (skip defeated)
- [x] Implement SAVING_ROLL phase: inline sanity wager input, D6 number selection (up to floor(wager/10) picks), resolve roll, restore hp=150 or mark defeated
- [x] Implement NEGOTIATION phase: show personality dialogue via typewriter, resolve by personality type, increment negstat, check win condition
- [x] Implement COMBAT_END phase: clear temp buffs, switch back to dungeon (or freeplay), pass result context
- [x] Implement Scarab Amulet handling during Horus fight: show SCARAB_DIALOGUE via typewriter, then switch to Khonshu boss fight
- [x] Render enemy HP/shield bar, charge indicator, enemy name/type/modifier
- [x] Apply animator.get_shake_offset() to viewport blit position each frame
**Dependencies:** [6, 3, 4, 7, 8, 9]

## Task 13: InventoryScene (scenes/inventory.py)
**Description:** Implement the inventory management screen for equipping, unequipping, and consuming items across party members.
**Sub-tasks:**
- [x] Implement `on_enter(context)`: store game_state and return_scene name
- [x] Render items grouped: EquippableItems, ConsumableItems, KeyItems
- [x] Render per-member equipment panel showing Weapon/Armor/Accessory slots
- [x] Handle equip action: call member.equip(item), if displaced item returned add back to inventory
- [x] Handle unequip action: call member.unequip(slot), add returned item to inventory
- [x] Handle consume action (ConsumableItems only): apply effect, remove from inventory
- [x] Render PLACEHOLDER background (inventory screen color)
- [x] On ESCAPE/back: switch_to return_scene with game_state
**Dependencies:** [6, 3, 9]

## Task 14: PartyScene (scenes/party.py)
**Description:** Implement the read-only party stat breakdown screen showing full details for all party members.
**Sub-tasks:**
- [x] Implement `on_enter(context)`: display full stat breakdown for all members
- [x] Render each member: all base stats, equipped items per slot, temp buffs, attack list, defeated status
- [x] Read-only; no modification of stats
- [x] On ESCAPE: return to calling scene
**Dependencies:** [6, 3, 9]

## Task 15: EndingScene (scenes/ending.py)
**Description:** Implement the three ending scenes that unlock freeplay mode and display the narrative conclusion via typewriter.
**Sub-tasks:**
- [x] Implement `on_enter(context)`: receive ending key ("good"/"dream"/"khonshu"), set game_state.freeplay_unlocked = True
- [x] Render PLACEHOLDER ending background
- [x] Display ending text via TypewriterRenderer (from data/dialogue.py: GOOD_ENDING, DREAM_ENDING, KHONSHU_ENDING)
- [x] After typewriter completes: show "Press ENTER to return to title"
- [x] On ENTER: switch_to("title", game_state)
**Dependencies:** [6, 7]

## Task 16: FreeplayScene (scenes/freeplay.py)
**Description:** Implement the endless freeplay combat sandbox with enemy selection, scaling difficulty, and streak tracking.
**Sub-tasks:**
- [x] Implement `on_enter(context)`: load game_state, show enemy type selector
- [x] Render enemy type list (all 4 standard types + 4 bosses); handle UP/DOWN/ENTER selection
- [x] On ENTER: generate selected enemy at current freeplay_difficulty, switch to "combat"
- [x] On return from combat victory: increment freeplay_streak; if streak % 5 == 0: freeplay_difficulty += 0.5
- [x] On return from combat defeat: offer "Resume [R]" (keep state) or "Title [T]" (reset streak)
- [x] Render win streak and highest difficulty in HUD area
**Dependencies:** [6, 4, 9, 12]

## Task 17: Boss fight integration
**Description:** Wire all four boss encounters into DungeonScene and CombatScene with their unique mechanics, scripted dialogue, and ending transitions.
**Sub-tasks:**
- [x] In DungeonScene: trigger Anubis fight on floor 4 exit (make_anubis(difficulty)), show ANUBIS_INTRO dialogue before fight
- [x] In DungeonScene: trigger Set fight on floor 6 exit (make_set(difficulty)), show SET_INTRO dialogue before fight
- [x] In DungeonScene: trigger Horus fight on floor 7 entry (make_horus(difficulty)), show HORUS_INTRO dialogue before fight
- [x] In CombatScene: implement Anubis sanity-check mechanic (if active_member.sanity < 75 at fight start: set anubis_low_sanity_flag; apply 1.5× multiplier to all Anubis attack damage)
- [x] In CombatScene: implement Set Desert Storm multi-hit (apply damage to ALL party members, not just active)
- [x] In CombatScene: implement Khonshu boss trigger via Scarab Amulet, show KHONSHU_BOSS_INTRO, switch to Khonshu fight
- [x] In CombatScene: on Khonshu hp ≤ 0: switch_to("ending", {"key": "good", "state": game_state})
- [x] In CombatScene: on Horus fight end (follow Horus): switch_to("ending", {"key": "dream", ...})
- [x] In CombatScene: on Khonshu fight player defeat: switch_to("ending", {"key": "khonshu", ...})
**Dependencies:** [11, 12, 15]

## Task 18: Property-based tests
**Description:** Implement property-based tests verifying all combat math formulas, class thresholds, and round-trip invariants.
**Sub-tasks:**
- [ ] Create `tests/test_combat_math.py`
- [ ] Install/import `hypothesis` (or use manual exhaustive loops if hypothesis unavailable)
- [ ] Test 1: non-negative player damage for all attack_base ∈ [1,20], d20 ∈ [1,20], attack_stat ≥ 0
- [ ] Test 2: D20 weight sum positive for all attack_stat, temp_attack ≥ 0
- [ ] Test 3: true-damage formula result ∈ [0, base_damage] for all blocked_dmg ∈ [0,100], true_dmg_pct ∈ [0,100]
- [ ] Test 4: enemy HP > 0 for all difficulty ∈ [1,10]
- [ ] Test 5: PlayerClass covers all sanity values ∈ [0,200] with no gaps or overlaps
- [ ] Test 6: charge idempotence — applying multiplier once = doubled; re-applying does not double again
- [ ] Test 7: equip round-trip — equip then unequip returns all stats to original values
- [ ] Test 8: saving roll deduction = floor(wagered/10)*10 for all wagered ≥ 0
**Dependencies:** [3, 4]
