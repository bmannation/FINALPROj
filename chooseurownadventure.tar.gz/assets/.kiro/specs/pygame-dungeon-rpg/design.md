# Design Document: Pygame Dungeon RPG

## Overview

This document describes the technical design for rewriting the terminal-based Egyptian-mythology dungeon crawler (`main.py`) into a full pygame-based turn-based RPG compatible with pygbag's asyncio web runtime. The design preserves all existing game mechanics (sanity system, d20/d6 rolling, saving roll, negotiation, enemy modifiers) and narrative content (three endings, Khonshu/Horus story, Scarab Amulet) while introducing graphical rendering, party management, animated combat, equippable gear, dungeon traversal, and freeplay mode.

---

## File Structure

```
chooseurownadventure/
├── main.py                  # Async entry point
├── engine.py                # SceneManager + main pygame loop
├── asciiart.py              # D20 ASCII art frames (keep as-is)
├── d6graphanim.py           # D6 ASCII art frames (keep as-is)
├── graphic.py               # Title art + misc ASCII (keep as-is)
├── scenes/
│   ├── __init__.py
│   ├── title.py             # TitleScene
│   ├── dungeon.py           # DungeonScene
│   ├── combat.py            # CombatScene
│   ├── inventory.py         # InventoryScene
│   ├── party.py             # PartyScene
│   ├── ending.py            # EndingScene (good / dream / khonshu endings)
│   └── freeplay.py          # FreeplayScene
├── entities/
│   ├── __init__.py
│   ├── party_member.py      # PartyMember dataclass + methods
│   ├── enemy.py             # Enemy dataclass + choose_attack()
│   ├── attack.py            # Attack dataclass
│   └── item.py              # ConsumableItem, EquippableItem, KeyItem
├── ui/
│   ├── __init__.py
│   ├── hud.py               # HUD renderer
│   ├── typewriter.py        # TypewriterRenderer
│   └── animator.py          # CombatAnimator
└── data/
    ├── __init__.py
    ├── attacks.py           # All attack definitions (player + enemy)
    ├── enemies.py           # All enemy type + boss definitions
    ├── items.py             # All item definitions + generation logic
    └── dialogue.py          # All narrative text strings (Khonshu, lore, etc.)
```

### Kept As-Is
- `asciiart.py` — referenced by CombatScene for the D20 roll animation (`a1`–`a20`).
- `d6graphanim.py` — referenced by CombatScene for the D6 roll animation (`d1`–`d6`).
- `graphic.py` — `graphic.title` rendered in TitleScene; `graphic.ankh` and `graphic.arch` used as decorative text art.

---

## Component Designs

### `main.py` — Async Entry Point

```python
import asyncio
import pygame
from engine import SceneManager
from entities.item import KeyItem
from data.dialogue import INTRO_TEXT

async def main():
    pygame.init()
    screen = pygame.display.set_mode((1024, 768))
    pygame.display.set_caption("Choose Ur Own Adventure")
    clock = pygame.time.Clock()
    manager = SceneManager(screen)
    from scenes.title import TitleScene  # avoid circular imports
    manager.register_all()
    manager.switch_to("title", None)
    while True:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            manager.handle_event(event)
        manager.update(dt)
        manager.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
```

**Key constraints:**
- No `time.sleep()` calls anywhere in the codebase.
- No `input()` calls anywhere; all text entry uses pygame event handling.
- All asset paths use `pathlib.Path(__file__).parent / "..."` for pygbag compatibility.

---

### `engine.py` — SceneManager

The `SceneManager` is the backbone of the scene graph. It holds a registry of named scenes, tracks the active scene, and routes all pygame events, update ticks, and draw calls.

```python
class SceneManager:
    def __init__(self, screen: pygame.Surface):
        self.screen = screen
        self.scenes: dict[str, Scene] = {}
        self.active: Scene | None = None
        self.active_name: str | None = None

    def register(self, name: str, scene: "Scene") -> None:
        self.scenes[name] = scene

    def register_all(self) -> None:
        # Import and register all scenes here to avoid circular imports
        from scenes.title import TitleScene
        from scenes.dungeon import DungeonScene
        from scenes.combat import CombatScene
        from scenes.inventory import InventoryScene
        from scenes.party import PartyScene
        from scenes.ending import EndingScene
        from scenes.freeplay import FreeplayScene
        self.register("title", TitleScene(self))
        self.register("dungeon", DungeonScene(self))
        self.register("combat", CombatScene(self))
        self.register("inventory", InventoryScene(self))
        self.register("party", PartyScene(self))
        self.register("ending", EndingScene(self))
        self.register("freeplay", FreeplayScene(self))

    def switch_to(self, name: str, context: object) -> None:
        if name not in self.scenes:
            print(f"[SceneManager] ERROR: scene '{name}' not found; staying on '{self.active_name}'")
            return
        if self.active is not None:
            self.active.on_exit()
        self.active_name = name
        self.active = self.scenes[name]
        self.active.on_enter(context)

    def handle_event(self, event: pygame.event.Event) -> None:
        if self.active:
            self.active.handle_event(event)

    def update(self, dt: float) -> None:
        if self.active:
            self.active.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        if self.active:
            self.active.draw(surface)
```

#### Scene Interface

Every scene must implement this interface:

```python
class Scene:
    def __init__(self, manager: SceneManager): ...
    def on_enter(self, context: object) -> None: ...
    def on_exit(self) -> None: ...
    def handle_event(self, event: pygame.event.Event) -> None: ...
    def update(self, dt: float) -> None: ...
    def draw(self, surface: pygame.Surface) -> None: ...
```

**Transition rules:**
- `switch_to` is always called within the current frame; there is no deferred transition queue.
- `on_exit()` is called on the departing scene before `on_enter(context)` is called on the arriving scene.
- `context` is typically the shared `GameState` object, but TitleScene receives `None`.

---

### `GameState` — Shared Context Object

`GameState` is created once at game start and threaded through every scene via `on_enter`. It holds all persistent run state.

```python
from dataclasses import dataclass, field
from entities.party_member import PartyMember
from entities.item import Item

@dataclass
class GameState:
    party: list[PartyMember] = field(default_factory=list)
    inventory: list[Item] = field(default_factory=list)
    floor: int = 1
    room: int = 0
    wins: int = 0
    freeplay_unlocked: bool = False
    freeplay_difficulty: float = 1.0
    freeplay_streak: int = 0
```

**Notes:**
- `inventory` is shared across all party members (no per-member inventory).
- `wins` increments on every combat victory and is used for freeplay difficulty scaling and attack generation.
- `freeplay_unlocked` is set to `True` when any ending scene is reached.

---

### `entities/party_member.py` — PartyMember

```python
from dataclasses import dataclass, field
from entities.attack import Attack
from entities.item import EquippableItem

PLAYER_CLASSES = ["Fiend", "Branded", "Human", "Enlightened", "Fanatical"]

@dataclass
class PartyMember:
    name: str
    hp: float
    max_hp: float
    sanity: int
    attack: int
    defense: int
    agility: int
    temp_attack: int = 0
    temp_defense: int = 0
    temp_agility: int = 0
    player_class: str = "Human"
    equipment: dict = field(default_factory=lambda: {"weapon": None, "armor": None, "accessory": None})
    defeated: bool = False
    attacks: list[Attack] = field(default_factory=list)

    def compute_class(self) -> str:
        s = self.sanity
        if s <= 50:
            self.player_class = "Fiend"
        elif s <= 74:
            self.player_class = "Branded"
        elif s <= 174:
            self.player_class = "Human"
        elif s <= 199:
            self.player_class = "Enlightened"
        else:
            self.player_class = "Fanatical"
        return self.player_class

    def equip(self, item: EquippableItem) -> EquippableItem | None:
        """Equip item; returns the displaced item (or None)."""
        slot = item.slot
        displaced = self.equipment[slot]
        if displaced is not None:
            self.unequip(slot)
        self.equipment[slot] = item
        self._apply_equip_delta(item, +1)
        return displaced

    def unequip(self, slot: str) -> EquippableItem | None:
        item = self.equipment.get(slot)
        if item is not None:
            self._apply_equip_delta(item, -1)
            self.equipment[slot] = None
        return item

    def _apply_equip_delta(self, item: EquippableItem, sign: int) -> None:
        if item.stat == "attack":
            self.attack += sign * item.value
        elif item.stat == "defense":
            self.defense += sign * item.value
        elif item.stat == "agility":
            self.agility += sign * item.value
        elif item.stat == "sanity":
            self.sanity += sign * item.value
            self.compute_class()
        elif item.stat == "playerhealth":
            self.max_hp += sign * item.value
            self.hp = min(self.hp, self.max_hp)

    def apply_temp_buff(self, stat: str, val: int) -> None:
        if stat == "attack":
            self.temp_attack += val
        elif stat == "defense":
            self.temp_defense += val
        elif stat == "agility":
            self.temp_agility += val

    def clear_temp_buffs(self) -> None:
        self.temp_attack = 0
        self.temp_defense = 0
        self.temp_agility = 0
```

**Slot → stat mapping:**
| Slot | Affected Stat |
|------|--------------|
| weapon | attack |
| armor | defense |
| accessory | agility, sanity, or playerhealth |

---

### `entities/attack.py` — Attack

```python
from dataclasses import dataclass

VALID_SPECIALS = {None, "critical", "selfdamage", "suicide", "chargeup"}

@dataclass
class Attack:
    name: str
    damage: int
    special: str | None = None  # One of VALID_SPECIALS

    def __post_init__(self):
        assert self.special in VALID_SPECIALS, f"Unknown special: {self.special}"
```

---

### `entities/enemy.py` — Enemy

```python
from dataclasses import dataclass, field
import random
from entities.attack import Attack

@dataclass
class Enemy:
    name: str
    enemy_type: str          # "Heretic" | "Creature" | "Revenant" | "Architect"
    modifier: str            # "Shielded" | "True Damage" | "Thief" | "Fanatic"
    hp: float
    shield_hp: float
    attack_pool: list[Attack]
    is_boss: bool = False
    charge_pending: Attack | None = None  # Set when a chargeup attack was chosen last turn

    def choose_attack(self) -> Attack:
        """
        Returns the attack to execute this turn.
        If charge_pending is set, returns it (with charge_pending then cleared by CombatScene).
        Otherwise picks randomly from attack_pool; if chargeup is chosen, sets charge_pending
        and returns a sentinel 'charging' attack so CombatScene can show the warning.
        """
        if self.charge_pending is not None:
            return self.charge_pending  # CombatScene clears this after resolving
        chosen = random.choice(self.attack_pool)
        if chosen.special == "chargeup":
            self.charge_pending = chosen
            # Return a zero-damage "charging" placeholder so CombatScene shows the warning
            return Attack(name=f"{chosen.name} (charging…)", damage=0, special="chargeup")
        return chosen
```

**Modifier effects (applied in CombatScene):**
| Modifier | Effect |
|----------|--------|
| Shielded | All player damage routes to `shield_hp` until `shield_hp == 0`, then to `hp` |
| True Damage | `true_dmgpercent = 5 * difficulty`; reduces defense effectiveness |
| Thief | On Victory: award 2 additional items from the permanent item pool |
| Fanatic | Enables Negotiate action; assigns a random human personality |

---

### `entities/item.py` — Item Classes

```python
from dataclasses import dataclass

class Item:
    """Base class for all items."""
    pass

@dataclass
class ConsumableItem(Item):
    name: str
    value: int
    affected: str      # stat name: "attack", "defense", "agility", "sanity", "playerhealth"
    is_temp: bool      # True = buff lasts until end of combat; False = permanent

@dataclass
class EquippableItem(Item):
    name: str
    stat: str          # "attack" | "defense" | "agility" | "sanity" | "playerhealth"
    value: int
    slot: str          # "weapon" | "armor" | "accessory"

@dataclass
class KeyItem(Item):
    name: str
    # Not usable, not discardable; only triggers effect in specific context (Horus fight)
```

**Predefined items (defined in `data/items.py`):**

Consumables (temporary buff, type `ConsumableItem` with `is_temp=True`):
- Ankh of Attack / Defense / Agility / Sanity / Health — stat buff, value `random.randint(3, 2*rarity+1)`, rarity-weighted drop

Equippables (type `EquippableItem`):
- Brass Knuckles: `stat="attack"`, `value=4`, `slot="weapon"`
- Essence of Vitality: `stat="playerhealth"`, `value=100`, `slot="accessory"`
- Ancient Tome of Power: `stat="attack"`, `value=2`, `slot="weapon"`
- Medallion of Resilience: `stat="defense"`, `value=3`, `slot="armor"`
- Elixir of Reflexes: `stat="agility"`, `value=5`, `slot="accessory"`
- Void-Touched Crystal: `stat="sanity"`, `value=50`, `slot="accessory"`
- Warrior's Heartstone: `stat="attack"`, `value=4`, `slot="weapon"`

Key items (type `KeyItem`):
- Scarab Amulet — triggers Khonshu boss fight when used during Horus fight; cannot be discarded

---

### `ui/typewriter.py` — TypewriterRenderer

```python
import pygame

class TypewriterRenderer:
    def __init__(
        self,
        text: str,
        font: pygame.font.Font,
        color: tuple[int, int, int],
        rect: pygame.Rect,
        chars_per_second: float = 40.0,
    ):
        self.text = text
        self.font = font
        self.color = color
        self.rect = rect
        self.chars_per_second = chars_per_second
        self.elapsed: float = 0.0
        self.chars_shown: int = 0
        self.complete: bool = False

    def update(self, dt: float) -> None:
        if self.complete:
            return
        self.elapsed += dt
        self.chars_shown = min(int(self.elapsed * self.chars_per_second), len(self.text))
        if self.chars_shown >= len(self.text):
            self.complete = True

    def draw(self, surface: pygame.Surface) -> None:
        visible = self.text[: self.chars_shown]
        self._render_wrapped(surface, visible)

    def _render_wrapped(self, surface: pygame.Surface, text: str) -> None:
        words = text.split(" ")
        lines: list[str] = []
        current = ""
        for word in words:
            test = (current + " " + word).strip()
            if self.font.size(test)[0] <= self.rect.width:
                current = test
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        line_height = self.font.get_linesize()
        for i, line in enumerate(lines):
            surf = self.font.render(line, True, self.color)
            surface.blit(surf, (self.rect.x, self.rect.y + i * line_height))

    def skip(self) -> None:
        self.chars_shown = len(self.text)
        self.elapsed = len(self.text) / self.chars_per_second
        self.complete = True

    def reset(self, new_text: str) -> None:
        self.text = new_text
        self.elapsed = 0.0
        self.chars_shown = 0
        self.complete = False
```

**Notes:**
- Callers check `.complete` to advance to the next dialogue beat — no events emitted.
- Space or Enter handling is done in the owning scene's `handle_event`; it calls `typewriter.skip()`.
- Does not block the game loop; safe to call `update(dt)` every frame.

---

### `ui/animator.py` — CombatAnimator

Tracks a list of active `Animation` objects. The scene loop calls `update(dt)` and `draw(surface)` every frame, and checks `is_playing` before advancing combat state.

```python
import pygame
from dataclasses import dataclass, field

@dataclass
class Animation:
    kind: str           # "attack_flash" | "hit_shake" | "hit_flash" | "critical_flash"
    duration: float     # total seconds
    elapsed: float = 0.0
    rect: pygame.Rect | None = None
    magnitude: float = 0.0
    color: tuple[int, int, int] = (255, 0, 0)
    alpha: int = 128

class CombatAnimator:
    def __init__(self):
        self._animations: list[Animation] = []
        self._shake_offset: tuple[int, int] = (0, 0)

    @property
    def is_playing(self) -> bool:
        return len(self._animations) > 0

    def trigger_attack_flash(self, sprite_rect: pygame.Rect) -> None:
        """200 ms bright white overlay on the attacker."""
        self._animations.append(Animation(
            kind="attack_flash", duration=0.200,
            rect=sprite_rect.copy(), color=(255, 255, 200), alpha=180,
        ))

    def trigger_hit_shake(self, damage: float) -> None:
        """300 ms screen shake; offset = min(damage/10, 20) px."""
        magnitude = min(damage / 10.0, 20.0)
        self._animations.append(Animation(
            kind="hit_shake", duration=0.300, magnitude=magnitude,
        ))

    def trigger_hit_flash(self, sprite_rect: pygame.Rect) -> None:
        """150 ms red-tint overlay at 50% opacity on the target."""
        self._animations.append(Animation(
            kind="hit_flash", duration=0.150,
            rect=sprite_rect.copy(), color=(220, 50, 50), alpha=128,
        ))

    def trigger_critical_flash(self, sprite_rect: pygame.Rect) -> None:
        """225 ms enlarged (1.5×) gold flash on the target."""
        inflated = sprite_rect.inflate(
            int(sprite_rect.width * 0.5),
            int(sprite_rect.height * 0.5),
        )
        self._animations.append(Animation(
            kind="critical_flash", duration=0.225,
            rect=inflated, color=(255, 215, 0), alpha=200,
        ))

    def update(self, dt: float) -> None:
        self._shake_offset = (0, 0)
        still_active: list[Animation] = []
        for anim in self._animations:
            anim.elapsed += dt
            if anim.elapsed < anim.duration:
                still_active.append(anim)
                if anim.kind == "hit_shake":
                    import math, random
                    phase = anim.elapsed / anim.duration
                    decay = 1.0 - phase
                    ox = int(math.sin(anim.elapsed * 60) * anim.magnitude * decay)
                    oy = int(random.uniform(-1, 1) * anim.magnitude * decay)
                    self._shake_offset = (ox, oy)
        self._animations = still_active

    def draw(self, surface: pygame.Surface) -> None:
        for anim in self._animations:
            if anim.rect is None:
                continue
            overlay = pygame.Surface((anim.rect.width, anim.rect.height), pygame.SRCALPHA)
            overlay.fill((*anim.color, anim.alpha))
            surface.blit(overlay, anim.rect.topleft)

    def get_shake_offset(self) -> tuple[int, int]:
        return self._shake_offset
```

CombatScene applies `get_shake_offset()` to its main viewport blit position each frame.

---

### `ui/hud.py` — HUD

The HUD occupies the rightmost 240 px of the 1024×768 screen (x=784, y=0, w=240, h=568).

```python
import pygame

PANEL_RECT = pygame.Rect(784, 0, 240, 568)
BAR_HEIGHT = 10
MEMBER_HEIGHT = 100  # vertical space per party member slot

COLORS = {
    "bg": (30, 25, 20),
    "text": (220, 200, 150),
    "text_defeated": (80, 70, 60),
    "hp_full": (80, 200, 80),
    "hp_low": (200, 80, 80),
    "sanity_bar": (100, 140, 220),
    "buff_text": (100, 160, 255),
    "border": (100, 80, 50),
}

class HUD:
    def __init__(self, font: pygame.font.Font, small_font: pygame.font.Font):
        self.font = font
        self.small_font = small_font

    def draw(self, surface: pygame.Surface, game_state) -> None:
        # PLACEHOLDER: Stone tablet texture with hieroglyph border
        panel = pygame.Surface((PANEL_RECT.width, PANEL_RECT.height))
        panel.fill(COLORS["bg"])
        pygame.draw.rect(panel, COLORS["border"], panel.get_rect(), 3)
        surface.blit(panel, PANEL_RECT.topleft)

        # Floor / room header
        header = self.small_font.render(
            f"Floor {game_state.floor}  Room {game_state.room}", True, COLORS["text"]
        )
        surface.blit(header, (PANEL_RECT.x + 8, 8))

        for i, member in enumerate(game_state.party):
            self._draw_member(surface, member, i)

    def _draw_member(self, surface: pygame.Surface, member, slot_index: int) -> None:
        y_base = 30 + slot_index * MEMBER_HEIGHT
        x = PANEL_RECT.x + 8
        color = COLORS["text"] if not member.defeated else COLORS["text_defeated"]

        # Name + class
        name_surf = self.font.render(f"{member.name}", True, color)
        surface.blit(name_surf, (x, y_base))
        class_surf = self.small_font.render(f"[{member.player_class}]", True, color)
        surface.blit(class_surf, (x, y_base + 16))

        # HP bar
        bar_w = PANEL_RECT.width - 16
        pygame.draw.rect(surface, (50, 50, 50), (x, y_base + 32, bar_w, BAR_HEIGHT))
        hp_ratio = max(0.0, member.hp / member.max_hp)
        bar_color = COLORS["hp_full"] if hp_ratio > 0.4 else COLORS["hp_low"]
        pygame.draw.rect(surface, bar_color, (x, y_base + 32, int(bar_w * hp_ratio), BAR_HEIGHT))
        hp_text = self.small_font.render(f"HP {int(member.hp)}/{int(member.max_hp)}", True, color)
        surface.blit(hp_text, (x, y_base + 44))

        # Sanity bar
        pygame.draw.rect(surface, (50, 50, 50), (x, y_base + 58, bar_w, BAR_HEIGHT))
        san_ratio = max(0.0, member.sanity / 200)
        pygame.draw.rect(surface, COLORS["sanity_bar"], (x, y_base + 58, int(bar_w * san_ratio), BAR_HEIGHT))
        san_text = self.small_font.render(f"SAN {member.sanity}", True, color)
        surface.blit(san_text, (x, y_base + 70))

        # Temp buff indicators
        buffs = []
        if member.temp_attack > 0:
            buffs.append(f"ATK ↑{member.temp_attack}")
        if member.temp_defense > 0:
            buffs.append(f"DEF ↑{member.temp_defense}")
        if member.temp_agility > 0:
            buffs.append(f"AGI ↑{member.temp_agility}")
        if buffs:
            buff_surf = self.small_font.render("  ".join(buffs), True, COLORS["buff_text"])
            surface.blit(buff_surf, (x, y_base + 84))
```

---

## Scene Designs

### `scenes/title.py` — TitleScene

- Renders `graphic.title` (ASCII art) using a monospace font in gold (`(212, 175, 55)`) via pygame surface blit.
- Below the title: "Press ENTER to start" (blinking at 1 Hz) and "Freeplay" (shown only if `GameState.freeplay_unlocked`).
- On ENTER: creates a new `GameState`, prompts for the first party member's name (inline text-entry input field), then switches to `"dungeon"`.
- On "F" key (freeplay): switches to `"freeplay"` if unlocked.
- Uses `graphic.title` string rendered line-by-line with `monospace_font.render(line, ...)`.

---

### `scenes/dungeon.py` — DungeonScene

#### Floor Generation

On `on_enter`, if entering a new floor:
1. Generate `random.randint(3, 6)` rooms.
2. Assign one room as "exit".
3. Assign remaining rooms weighted: `combat 60%, item 20%, rest 10%, lore 10%`.
4. Build a simple linear or branching graph (list of node positions + edges).

```python
from dataclasses import dataclass

ROOM_COLORS = {
    "combat":  (180, 50,  50),   # red
    "item":    (200, 170, 50),   # gold
    "rest":    (50,  160, 80),   # green
    "lore":    (120, 50,  180),  # purple
    "exit":    (220, 220, 220),  # white
    "cleared": (80,  80,  80),   # grey
}

@dataclass
class Room:
    room_type: str         # "combat" | "item" | "rest" | "lore" | "exit"
    cleared: bool = False
    pos: tuple[int, int] = (0, 0)  # screen position of node circle
```

#### Room Entry Logic

```
On enter room:
  if room.cleared or room.type == "exit":
    handle accordingly
  elif room.type == "combat":
    generate enemy → switch_to("combat", CombatContext(game_state, enemy, room))
  elif room.type == "item":
    call itemsmake(difficulty) → add to inventory → show typewriter confirmation
    room.cleared = True
  elif room.type == "rest":
    for member in party: member.hp = min(member.max_hp, member.hp + member.max_hp * 0.25)
    room.cleared = True
  elif room.type == "lore":
    pick a lore string from data/dialogue.py → show via TypewriterRenderer
    room.cleared = True
  elif room.type == "exit":
    game_state.floor += 1 → regenerate floor or transition to boss
```

#### Map Rendering

Rooms are rendered as circles (radius 20 px) connected by lines in the main viewport (784×568).

```
# PLACEHOLDER: Dark stone dungeon floor with cracked tiles
viewport = pygame.Surface((784, 568))
viewport.fill((20, 18, 14))
```

Draw edges first, then circles, then room-type color, then current-room highlight ring.

#### Difficulty Formula

```python
difficulty = 1 + ((game_state.floor - 1) // 2)
```

| Floor | Difficulty |
|-------|-----------|
| 1–2   | 1         |
| 3–4   | 2         |
| 5–6   | 3         |
| 7     | 4         |

Every third floor, `DungeonScene` calls `attackmake()` and prompts the player to name a new attack (attack damage = `random.randint(attack_stat, attack_stat + wins)`).

---

### `scenes/combat.py` — CombatScene

#### Internal State Machine

```python
from enum import Enum, auto

class CombatPhase(Enum):
    PLAYER_CHOOSE_ACTION = auto()
    PLAYER_CHOOSE_ATTACK = auto()
    ROLL_D20             = auto()
    ANIMATE_ATTACK       = auto()
    ENEMY_TURN           = auto()
    ANIMATE_HIT          = auto()
    CHECK_WIN_LOSS       = auto()
    SAVING_ROLL          = auto()
    NEGOTIATION          = auto()
    COMBAT_END           = auto()
```

#### Turn Flow

```
PLAYER_CHOOSE_ACTION
  → user selects: [A]ttack / [B]lock / [I]tem / [N]egotiate (if available)

If Attack:
  PLAYER_CHOOSE_ATTACK → list member.attacks, user picks one
  ROLL_D20 → animate d20 using asciiart frames, resolve damagemult
  ANIMATE_ATTACK → animator.trigger_attack_flash(member_rect)
               → if critical: prompt D6 guess, roll, animator.trigger_critical_flash if hit
  (calculate damage, apply to enemy)
  → ENEMY_TURN

If Block:
  set blocking = True
  → ENEMY_TURN

If Item:
  open item submenu (inline within this phase)
  apply item effect
  → ENEMY_TURN

If Negotiate:
  NEGOTIATION phase: resolve by personality, increment negstat
  if negstat >= difficulty: combat ends as negotiation victory
  else: enemy retaliates → ENEMY_TURN

ENEMY_TURN
  call enemy.choose_attack()
  if attack.special == "chargeup" (charging): show warning, skip damage → CHECK_WIN_LOSS
  else:
    ANIMATE_HIT → animator.trigger_hit_shake(damage) + animator.trigger_hit_flash(member_rect)
    apply damage (respecting blocking flag, true_dmg modifier, shield routing)
    → CHECK_WIN_LOSS

CHECK_WIN_LOSS
  if enemy.hp <= 0: victory path → award items, wins++, COMBAT_END
  if member.hp <= 0: SAVING_ROLL for that member
    if all members defeated: game over → switch_to("ending", khonshu_ending_context)
  else → PLAYER_CHOOSE_ACTION (advance active_member index)

SAVING_ROLL
  prompt sanity wager (numeric input) + D6 number picks
  deduct sanity = wager (floor(wager/10)*10 deducted; remainder kept by Khonshu)
  roll D6; if result in chosen numbers: restore member.hp = 150
  else: member.defeated = True
  → CHECK_WIN_LOSS

COMBAT_END
  clear all temp buffs via member.clear_temp_buffs()
  return to DungeonScene (mark room cleared) or FreeplayScene
```

#### Damage Formulas

**Player attack:**
```python
real_damage = round((attack.damage * d20_roll) / 1.5, 1) + member.attack
# If critical hit confirmed: real_damage *= 3
```

**D20 weight distribution:**
```python
weights = [1.0] * 12 + [0.2 * member.attack] * 5 + [0.3 * (member.temp_attack + 1)] * 3
result = random.choices(range(1, 21), weights=weights, k=1)[0]
```

**Enemy attack — standard:**
```python
attack_damage = attack.damage * (5 * difficulty)
real_attack_damage = round(attack_damage * ((100 - blocked_dmg) / 100), 1)
# blocked_dmg = member.defense * 2
# If blocking: real_attack_damage /= 2
```

**Enemy attack — true damage:**
```python
true_dmg_pct = 5 * difficulty
real_attack_damage = round(
    attack_damage * ((100 - (blocked_dmg * ((100 - true_dmg_pct) / 100))) / 100), 1
)
```

**Charge resolution:**
```python
# On charge turn: store attack in enemy.charge_pending, show warning, deal 0 damage
# On next enemy turn: damage = charge_pending.damage * 2 * (5 * difficulty)
# Then clear enemy.charge_pending
```

**Self-damage specials:**
```python
# selfdamage: enemy_hp -= round(real_attack_damage / 0.7)
# suicide: enemy_hp = enemy_hp * 0.1
```

#### Shielded Modifier

```python
if enemy.modifier == "Shielded":
    if enemy.shield_hp > 0:
        enemy.shield_hp = max(0, enemy.shield_hp - real_damage)
    else:
        enemy.hp -= real_damage
```

#### Negotiation

```python
human_personality = random.choice(["Nervous", "Angry", "Corrupt", "Longing"])

# Longing: roll D6 vs random pool of 3 from [1-6]; negstat++ on match
# Angry: enemy.hp < enemy.hp_max * 0.5 → negstat++; else enemy attacks
# Nervous: member.agility >= difficulty + difficulty//2 → negstat++; else enemy attacks
# Corrupt: player chooses Y/N to sacrifice difficulty*7 sanity; Y → negstat += 5
# Win condition: negstat >= difficulty
# On victory: member.sanity += 10 * difficulty
```

#### Scarab Amulet (during Horus fight)

```python
if item == scarab_item and enemy.name == "Horus":
    typewriter.reset(SCARAB_DIALOGUE)  # from data/dialogue.py
    # After typewriter completes:
    switch_to("combat", KhonshuBossContext(game_state))
```

#### Active Member Rotation

Each turn, the active member advances through the party roster (index wraps). Defeated members are skipped.

```python
def next_active_member(party: list[PartyMember], current_idx: int) -> int:
    n = len(party)
    for i in range(1, n + 1):
        next_idx = (current_idx + i) % n
        if not party[next_idx].defeated:
            return next_idx
    return -1  # all defeated
```

---

### `scenes/inventory.py` — InventoryScene

- Accessible from DungeonScene (between rooms) and from CombatScene (Item action).
- Displays items grouped by type: EquippableItems, ConsumableItems, KeyItems.
- Per-party-member equipment panel shows current loadout with slot labels.
- Equipping an item that displaces another returns the displaced item to inventory.
- Uses `manager.switch_to` to return to the calling scene (passed in context).

---

### `scenes/party.py` — PartyScene

- Shows full stat breakdown for each PartyMember.
- Shows equipped items, all attacks, and temp buff status.
- Read-only during combat; allows attack inspection but no action.

---

### `scenes/ending.py` — EndingScene

Three ending variants selected by context:

| Context Key | Ending |
|-------------|--------|
| `"good"` | Defeat Khonshu → Good Ending (dungeon was a prison) |
| `"dream"` | Follow Horus → Dream Ending |
| `"khonshu"` | Player defeated by Khonshu → Khonshu Ending |

Each ending:
1. Plays scripted dialogue via TypewriterRenderer (strings from `data/dialogue.py`).
2. Sets `game_state.freeplay_unlocked = True`.
3. Offers return to TitleScene.

---

### `scenes/freeplay.py` — FreeplayScene

- Unlocked after any ending; accessible from TitleScene.
- `difficulty = game_state.freeplay_difficulty` (starts at 1.0, +0.5 every 5 wins).
- Pre-fight enemy selector: list of all enemy types + boss types.
- On victory: `game_state.freeplay_streak++`; if `streak % 5 == 0`: `freeplay_difficulty += 0.5`.
- On defeat: offer "Resume" (keep difficulty + streak) or "Back to Title" (reset streak, keep freeplay_difficulty).
- HUD shows current win streak and highest difficulty reached (stored in `GameState.freeplay_streak`).

---

## Rendering Layout

```
+----------------------------------------------------------+
|  Main Viewport (784 × 568)                    | HUD      |
|  combat / dungeon / title / etc.              | 240 × 568|
|                                               |          |
+----------------------------------------------------------+
|  Dialogue Box (1024 × 200) — TypewriterRenderer          |
+----------------------------------------------------------+

Screen:       1024 × 768
Viewport:      784 × 568  (x=0,   y=0)
HUD:           240 × 568  (x=784, y=0)
Dialogue box: 1024 × 200  (x=0,   y=568)
```

### Dialogue Box

```python
DIALOGUE_RECT = pygame.Rect(0, 568, 1024, 200)

# PLACEHOLDER: Carved stone slab with hieroglyph border
dialogue_bg = pygame.Surface((1024, 200))
dialogue_bg.fill((25, 20, 15))
pygame.draw.rect(dialogue_bg, (100, 80, 50), dialogue_bg.get_rect(), 3)
```

The `TypewriterRenderer` is initialized with `rect=pygame.Rect(12, 580, 1000, 188)` (inset from dialogue box edges).

---

## Async Loop Design

```python
# main.py
import asyncio
import pygame
from engine import SceneManager

async def main():
    pygame.init()
    screen = pygame.display.set_mode((1024, 768))
    pygame.display.set_caption("Choose Ur Own Adventure")
    clock = pygame.time.Clock()
    manager = SceneManager(screen)
    manager.register_all()
    manager.switch_to("title", None)

    while True:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            manager.handle_event(event)
        manager.update(dt)
        manager.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)  # yield to browser event loop (pygbag requirement)

asyncio.run(main())
```

**Rules enforced across all files:**
- No `time.sleep()` anywhere.
- No `input()` anywhere; text entry uses `pygame.KEYDOWN` events with a per-scene input buffer string.
- All blocking loops converted to state machine phases checked in `update(dt)`.

---

## Placeholder Convention

All art assets are represented as filled `pygame.Surface` objects. The convention is:

```python
# PLACEHOLDER: [description of intended artwork]
surf = pygame.Surface((w, h))
surf.fill((r, g, b))
```

**No external image files are loaded.** All `pygame.image.load()` calls are absent.

Per-scene placeholder descriptions:

| Scene / Element | Placeholder Description |
|----------------|-------------------------|
| HUD panel | Stone tablet texture with hieroglyph border |
| DungeonScene background | Dark stone dungeon floor with cracked tiles |
| Combat background | Underground arena with torchlit sandstone walls |
| Party member sprite | Filled rectangle (60×80 px) in class color with name label |
| Enemy sprite | Filled rectangle (80×100 px) in type color with name label |
| Item cache room | Treasure alcove with golden artifacts |
| Rest room | Underground shrine with Ankh carvings |
| Lore room | Papyrus scroll unrolled on stone pedestal |
| Dialogue box | Carved stone slab with hieroglyph border |
| Title screen background | Starfield over the Nile at night |

---

## Data Tables

### `data/attacks.py` — Attack Definitions

#### Enemy Attacks

```python
# Heretic
Stab         = Attack("Stab",         damage=2, special=None)
Slash        = Attack("Slash",        damage=2, special=None)
DaggerThrow  = Attack("Dagger Throw", damage=3, special=None)
BloodSpit    = Attack("Blood Spit",   damage=4, special=None)
Sacrifice    = Attack("Sacrifice",    damage=6, special="suicide")

# Creature
Shudder      = Attack("Shudder",  damage=1, special=None)
Bite         = Attack("Bite",     damage=2, special=None)
Scream       = Attack("Scream",   damage=3, special=None)
Claw         = Attack("Claw",     damage=4, special=None)
Shatter      = Attack("Shatter",  damage=5, special="selfdamage")

# Revenant
Wail         = Attack("Wail",      damage=2, special="chargeup")
Drain        = Attack("Drain",     damage=3, special="selfdamage")
Haunt        = Attack("Haunt",     damage=4, special=None)
SoulRend     = Attack("Soul Rend", damage=5, special="chargeup")

# Architect
Construct       = Attack("Construct",        damage=2, special=None)
Reinforce       = Attack("Reinforce",        damage=0, special=None)   # restores shield_hp
BlueprintStrike = Attack("Blueprint Strike", damage=4, special=None)
Collapse        = Attack("Collapse",         damage=5, special="chargeup")
```

**`Reinforce` handling in CombatScene:**
```python
if chosen_attack.name == "Reinforce":
    enemy.shield_hp += 20 * difficulty  # mid-combat shield restore
    # show typewriter message; skip damage calculation
```

#### Player Starting Attacks

```python
Punch  = Attack("Punch",  damage=5, special=None)
Tackle = Attack("Tackle", damage=4, special="critical")
```

---

### `data/enemies.py` — Enemy Definitions

#### Random Enemy Pool

```python
ATTACK_POOLS = {
    "Heretic":   [Stab, Slash, DaggerThrow, BloodSpit, Sacrifice],
    "Creature":  [Shudder, Bite, Scream, Claw, Shatter],
    "Revenant":  [Wail, Drain, Haunt, SoulRend],
    "Architect": [Construct, Reinforce, BlueprintStrike, Collapse],
}

ENEMY_NAMES = ["Bryton", "Owen", "Ridwan", "Khafra", "Nebka", "Thutmose", "Senusret", "Amet"]
MODIFIERS   = ["Shielded", "True Damage", "Thief", "Fanatic"]

def make_enemy(difficulty: float) -> Enemy:
    enemy_type = random.choice(list(ATTACK_POOLS.keys()))
    modifier   = random.choice(MODIFIERS)
    hp         = random.randint(55, 85) * (1 + 0.5 * difficulty)
    shield_hp  = (50 * (random.randint(1, 5 * int(difficulty)) / 10 + 1)
                  if modifier == "Shielded" else 0)
    return Enemy(
        name=random.choice(ENEMY_NAMES),
        enemy_type=enemy_type,
        modifier=modifier,
        hp=hp,
        shield_hp=shield_hp,
        attack_pool=ATTACK_POOLS[enemy_type],
        is_boss=False,
    )
```

#### Boss Definitions

| Boss | Floor | Modifier | hp formula | shield_hp formula | Special Mechanics |
|------|-------|----------|-----------|-------------------|-------------------|
| Anubis | 4 | True Damage | `random.randint(55,85)*(1+0.5*diff)*2` | — | Scales of Ma'at (chargeup, `8*diff` dmg); if active_member.sanity < 75: deal 1.5× all attacks |
| Set | 6 | Shielded | `random.randint(55,85)*(1+0.5*diff)*2.5` | `80*diff` | Desert Storm (chargeup, 10 base) hits ALL party members |
| Horus | 7 | Fanatic | `random.randint(55,85)*(1+0.5*diff)*3` | — | Attack pool: Gale Wing(3), Talon Sweep(4), Solar Flare(5), Vengeance(6,selfdamage), Judgement(7,selfdamage); Scarab Amulet ends fight |
| Khonshu | 7 (triggered) | True Damage | `random.randint(55,85)*(1+0.5*diff)*3.5` | — | Defeat Khonshu → Good Ending; player defeat → Khonshu Ending |

```python
def make_anubis(difficulty: float) -> Enemy: ...
def make_set(difficulty: float) -> Enemy: ...
def make_horus(difficulty: float) -> Enemy: ...
def make_khonshu(difficulty: float) -> Enemy: ...
```

Each boss constructor sets `is_boss=True` and uses the attack pools above.

---

### `data/items.py` — Item Generation

```python
import random
from entities.item import ConsumableItem, EquippableItem, KeyItem

SCARAB_AMULET = KeyItem(name="Scarab Amulet")
BRASS_KNUCKLES = EquippableItem(name="Brass Knuckles", stat="attack", value=4, slot="weapon")

PERM_ITEMS = [
    EquippableItem("Essence of Vitality",     stat="playerhealth", value=100, slot="accessory"),
    EquippableItem("Ancient Tome of Power",   stat="attack",       value=2,   slot="weapon"),
    EquippableItem("Medallion of Resilience", stat="defense",      value=3,   slot="armor"),
    EquippableItem("Elixir of Reflexes",      stat="agility",      value=5,   slot="accessory"),
    EquippableItem("Void-Touched Crystal",    stat="sanity",       value=50,  slot="accessory"),
    EquippableItem("Warrior's Heartstone",    stat="attack",       value=4,   slot="weapon"),
]

def generate_consumable(rarity: int) -> ConsumableItem:
    weights  = [8, 7, 3 + rarity, 10, 1]
    options  = ["attack", "defense", "sanity", "playerhealth", "agility"]
    stat     = random.choices(options, weights=weights, k=1)[0]
    value    = random.randint(3, 2 * rarity + 1)
    stat_label = "Health" if stat == "playerhealth" else stat.capitalize()
    name_options = [
        f"Ankh of {stat_label}",
        f"Sigil of {stat_label}",
        f"Rune of {stat_label}",
    ]
    return ConsumableItem(name=random.choice(name_options), value=value, affected=stat, is_temp=True)
```

---

### `data/dialogue.py` — Narrative Text

All Khonshu narrator text, boss pre-fight dialogue, lore fragments, and ending text strings are stored as constants here, keeping the scene files clean.

```python
# Narrator style: calm, god-like, second-person address

KHONSHU_INTRO = (
    "You have come far. The dungeon remembers you, child. "
    "Do not mistake its silence for welcome."
)

SCARAB_DIALOGUE = (
    "A light washes over you. Horus's eyes widen as his prepared attack falters. "
    "He steps back. As he does, the dungeon unravels. "
    "It is a true dungeon — one built to contain a god.\n\n"
    "Horus: 'You see the truth now. Good. My work here is done.'\n\n"
    "Khonshu: 'That Scarab... I should have seen this coming. "
    "It cannot be helped. I must do some things myself.'"
)

GOOD_ENDING = (
    "The prison shatters. Khonshu's form dissolves into moonlight. "
    "Horus watches from the threshold, nodding once. "
    "You walk out into a world that does not know what it owes you."
)

DREAM_ENDING = (
    "You follow Horus through the fracture in the dungeon wall. "
    "The waking world recedes. In the dream, there is no Khonshu, "
    "no dungeon, no debt. Only the quiet weight of a choice you can never undo."
)

KHONSHU_ENDING = (
    "Rest, my child. The mortal world is mine to take over."
)

ANUBIS_INTRO = (
    "The scales tip. Anubis regards you with the patience of ten thousand years. "
    "'Your heart will be weighed. It always is.'"
)

SET_INTRO = (
    "The desert answers to no one. Set smiles. "
    "'You are very far from home.'"
)

HORUS_INTRO = (
    "Horus lands in front of you, wings folding. "
    "'I do not want to fight you. But I will, if you make me.'"
)

KHONSHU_BOSS_INTRO = (
    "The god steps through the ruin of the dungeon's heart. "
    "His crook-and-flail gleam with borrowed moonlight. "
    "'Did you think the cage had no owner?'"
)

LORE_FRAGMENTS = [
    "A page from Thoth's grimoire: 'The dead remember everything. That is their punishment.'",
    "Scrawled on the wall in old ink: 'Ma'at does not forgive. She simply measures.'",
    "A passage from the Book of the Dead: 'Speak your name, and the gate opens. Forget it, and you become the gate.'",
    "A carved relief, partially destroyed: '...the moon god built this place to forget what he had done...'",
    "Loose papyrus, illegible except for one line: 'Horus was right about everything.'",
    "A stone tablet: 'Seven floors. Seven judges. The eighth judge is the one you brought with you.'",
]

SAVING_ROLL_PROMPT = (
    "My followers do not accept death. Put your sanity on the line — "
    "10 points for one number. How much of your sanity will it cost you?"
)

SAVING_ROLL_CHANGE = "I keep change."
SAVING_ROLL_SUCCESS = "Use this chance wisely. Not many return from death."
SAVING_ROLL_FAILURE = "Unlucky. Close your eyes."
```

---

## PlayerClass Thresholds

| Class | Sanity Range | Combat Effect |
|-------|-------------|---------------|
| Fiend | 0–50 | +2 bonus to base attack for duration of combat |
| Branded | 51–74 | No special effect |
| Human | 75–174 | No special effect |
| Enlightened | 175–199 | No special effect |
| Fanatical | 200 | Negotiate available against all enemy types (not just Fanatic modifier) |

```python
def compute_class(sanity: int) -> str:
    if sanity <= 50:    return "Fiend"
    if sanity <= 74:    return "Branded"
    if sanity <= 174:   return "Human"
    if sanity <= 199:   return "Enlightened"
    return "Fanatical"
```

**Sanity ≤ 0 — Berserk state:**
When a member's sanity reaches 0, CombatScene treats that member's attack action as randomly targeting either an enemy or a party member (50/50 each turn).

---

## Difficulty Scaling Summary

| Parameter | Formula |
|-----------|---------|
| Floor difficulty | `1 + ((floor - 1) // 2)` |
| Enemy HP | `random.randint(55, 85) * (1 + 0.5 * difficulty)` |
| Enemy attack damage | `attack.damage * (5 * difficulty)` |
| Set shield HP | `80 * difficulty` |
| Anubis Scales of Ma'at | `8 * difficulty` damage (after charge) |
| True damage pierce | `5 * difficulty` percent of defense bypassed |
| Freeplay difficulty start | 1.0 |
| Freeplay difficulty increment | +0.5 every 5 wins |
| Negotiation sanity award | `10 * difficulty` |
| Corrupt negotiation sanity cost | `7 * difficulty` |

---

## Property-Based Test Targets (`tests/test_combat_math.py`)

The following invariants must hold for all valid input ranges and must be covered by property-based tests (using `hypothesis` or equivalent):

1. **Non-negative player damage:** `∀ attack_base ∈ [1,20], d20 ∈ [1,20], attack_stat ≥ 0 → damage ≥ 0`
2. **D20 weight sum positive:** `∀ attack_stat, temp_attack ≥ 0 → sum(weights) > 0`
3. **True-damage formula bounded:** `∀ blocked_dmg ∈ [0,100], true_dmg_pct ∈ [0,100] → result ∈ [0, base_damage]`
4. **Enemy HP positive:** `∀ difficulty ∈ [1,10] → randint(55,85)*(1+0.5*diff) > 0`
5. **PlayerClass covers all sanity values:** `∀ sanity ∈ [0,200] → exactly one class label returned`
6. **Charge idempotence:** applying charge multiplier once (damage × 2) equals the final value; re-resolving does not double again
7. **Equip round-trip:** `equip(item); unequip(slot)` returns all stats to original values for all valid item modifiers
8. **Saving roll sanity deduction:** deducted = `floor(wagered/10)*10`; remainder `wagered%10` is lost (non-refundable) for all `wagered ≥ 0`
